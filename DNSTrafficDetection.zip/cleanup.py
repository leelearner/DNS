import os

if os.path.exists("installRecords.txt"):
    f = open("installRecords.txt", 'r', encoding= "utf-8")
    try:
        for path in f.readlines():
            os.remove(path.strip("\n").strip("\r\n"))
        f.close()
    except Exception:
        print(Exception)
        pass
    os.remove("installRecords.txt")
print("clean up finish!")
