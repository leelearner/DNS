from setuptools import setup

setup(
    name='DNS Trafic Utils',
    version='1.0',
    scripts=['trafficutils.py', 'customfirewall.py'],
    author = "tulip trainer",
    install_requires=['pyshark'],
    description='Utilities to identify the DNS message from network traffic',
    py_modules=['trafficutils', 'customfirewall']
)