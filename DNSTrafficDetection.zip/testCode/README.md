#Important#

The blocking traffic function relies on operating the linux itables firewall so the root privilege is essential to run the simple codes.

# Block Traffic #
The **blocking\_traffic method** in customfirewall.py can block the traffic of a specified source IP for a custom time span (default is 300 seconds). The first parameter of this method is **blocked\_ip\_list** which is a map contains the source IP and corresponding start blocking time. The second parameter of this method is **blockTime**  (default is 300 seconds).

The sample code invokes this method as follows:

    from customfirewall import blocking_traffic
    from customfirewall import reset_block_rule
    import time

    blocked_ip_list = {"127.0.0.1":str(time.time()), "128.0.0.2":str(time.time())}
    blocking_traffic(blocked_ip_list, 10)
    # delete the block rule about a specific IP
    reset_block_rule("127.0.0.1")

# Offline DNS traffic identify and Block
The **label\_dns\_in\_kafka\_traffic** method in trafficutils.py can identify the dns message which transfer over kafka message system (Offline mode). The parameter of this method are [capfile, outputPath="", hasPrintaleText=False, isBlockTraffic=False, blockTime]. 

The **capfile** parameter denotes the original package file path. The **outputPath** parameter denotes the directory of the output file (default is "./"), which represents the current directory. The **hasPrintableText** parameter denotes whether preserve the parsed package content in the output file (default is false). The **isBlockTraffic** method denotes whether block the traffic when parsing the captured package file (default is false). The **blockTime** parameter denotes the expected block time when enabling block traffic by the previous parameter(default is 300 seconds).

The sample code invokes this method as follows:

    from trafficutils import label_dns_in_kafka_traffic
    label_dns_kafka_traffic("./dns_data.cap")
    
    label_dns_kafka_traffic("./test.cap", isBlockTraffic=True) 
    # specific the block time when detect the dns message 
    label_dns_kafka_traffic("./test.cap", isBlockTraffic=True, blockTime=30)
#Online DNS traffic identify and Block #

The live\_dns\_detect\_in\_kafka\_traffic method in trafficutils.py can identify the dns message which transfer over kafka message system (Online mode). The parameters of this method are [interface=None, capture\_filter=None, output\_file=None, result\_file=None, hasPrintaleText=False, packet\_count=None]. 

The **interface** parameter denotes the name of the interface to sniff on or a list of names (str). The **capture\_filter** parameter denotes Capture (Wireshark) filter to use. The **output\_file** parameter denotes the filename that the live captured packets will save (default is None). The **result\_file** parameter denotes the path to store the parsed package data (default is ParsedResult.csv). The **hasPrintableText** parameter denotes whether preserve the parsed package content in the output file (default is false). The **packet_count** parameter denotes the total count of the packet want to sniff (Default is None) means the program will continue to sniff the package until the user stops the program. The **isBlockTraffic** parameter denotes whether block the traffic when sniffing the live package. The **blockTime** parameter denotes the expected block time when enabling block traffic by the previous parameter(default is 300 seconds). The **cacheExpireTime** parameter is used to set the default LRU cache expiring time, in the living model the LRU cache is used to avoid repeat the traffic from a specific IP (default is 600 seconds)

The sample code invokes this method as follows:

    from trafficutils import  live_dns_detect_in_kafka_traffic
    
    live_dns_detect_in_kafka_traffic(interface=["ens33", "ens32"], packet_count=5)
    live_dns_detect_in_kafka_traffic(interface="ens33", packet_count=10)
    # detect and block the suspicious traffic (500 seconds)
    live_dns_detect_in_kafka_traffic(interface="ens33", isBlockTraffic=True, blockTime=500)
    # detect and block the suspicious traffic and change default cache expire time
    live_dns_detect_in_kafka_traffic(interface="ens33", isBlockTraffic=True, blockTime=30, cacheExpireTime=40)




    





 




    
    


