import pyshark
from sklearn.svm import OneClassSVM
import codecs
import string
from pathlib import Path
from customfirewall import blocking_traffic
import time
from lru import lazy_cache

def label_dns_in_kafka_traffic(capfile, outputPath="./", hasPrintaleText=False, isBlockTraffic=False, blockTime = 300):
  # Output CSV formats
  # Id (auto), Time, Source IP, Source Port, Destination IP, Destination Port, highest_layer,Printable Text,IsKafka Traffic,Is DNS Message
  cap = pyshark.FileCapture(capfile, include_raw=True, use_json=True)
  if hasPrintaleText:
    parsedDataHeaders = "Sep,Time,Identification(IP),Source IP,Source Port,Destination IP,Destination Port,Highest_layer,Printable Text,IsKafka Traffic,IsDNS Message"
  else:
    parsedDataHeaders = "Sep,Time,Identification(IP),Source IP,Source Port,Destination IP,Destination Port,Highest_layer,IsKafka Traffic,IsDNS Message"
  CSV_SEP = ","
  seq = 0
  isDnsMessage = "False"
  blocked_ip_list = {}
  outPutFilename = Path(capfile).name.split(".")[0] + ".csv"
  if outputPath == "./":
    outputPath = outputPath + outPutFilename
  else:
    outputPath = outputPath.strip("/") + "/" + outPutFilename + ".csv"
  f = codecs.open(outputPath, mode="w", encoding="utf-8")
  f.writelines(parsedDataHeaders + "\r\n")
  for packet in cap:
    seq = seq + 1
    ptime = packet.frame_info.time.replace(",", " ")
    identification = packet.ip.id.replace(",", " ")
    try:
      sourceIp = packet.ip.src
    except Exception:
      sourceIp = ""
    try:
      sourcePort = packet.tcp.srcport
    except Exception:
      sourcePort = ""
    try:
      destinationIp = packet.ip.dst
    except Exception:
      destinationIp = ""
    try:
      destinationPort = packet.tcp.dstport
    except Exception:
      destinationPort = ""
    try:
      highestLayer = packet.highest_layer.replace(",", " ")
    except Exception:
      highestLayer = ""

    isData = "DATA" in packet
    isSMPP = "SMPP" in packet
    isKafkaMsg = isData or isSMPP
    hex_message = ""
    printableText = ""
    line = ""
    if isData or is isSMPP:
      if isData:
        try:
          hex_message = packet.highest_layer.replace(packet.data_raw.value)
        except Exception:
          hex_message = ""
      if isSMPP:
        try:
          hex_message = packet.smpp_raw.value.replace(",", " ").replace("\r\n", " ").replace('\r', ' ').replace("\n", " ")
        except Exception:
          hex_message = ""
      try:
        printableText = bytes.fromhex(str(hex_message)).decode("utf-8", "ignore")
        printableText = "".join(filter(lambda x: x in string.printable, printableText)).replace(",", " ").replace(
          "\r\n", " ").replace('\r', ' ').replace("\n", " ")
      except Exception:
        printableText = "@SECRYTEXTLABLE@" + str(len(hex_message))
    if len(printableText) > 0:
      lowerText = printableText.lower()
      if "@SECRYTEXTLABLE@" in printableText:
        feature = [int(printableText.split("@SECRYTEXTLABLE@")[1])]
        clf = OneClassSVM(gamma='auto').fit(feature)
        outPut = int(clf.predict(feature)[0])
        if outPut > 0:
          isDnsMessage = True
        else:
          isDnsMessage = False
      else:
        isDnsMessage = "opcode" in lowerText and "question" in lowerText and "answer" in lowerText and "authority" in lowerText and "additional" in lowerText
      # as hex_message is too long we do not store it now.
      # line = str(seq) + CSV_SEP + ptime + CSV_SEP + identification + CSV_SEP + sourceIp + CSV_SEP + sourcePort + CSV_SEP + \
      #        destinationIp + CSV_SEP + destinationPort + CSV_SEP + highestLayer + CSV_SEP + hex_message + CSV_SEP + \
      #        printableText + CSV_SEP + str(isKafkaMsg) + CSV_SEP + str(isDnsMessage) + "\r\n"

    line = str(seq) + CSV_SEP + str(ptime) + CSV_SEP + str(identification) + CSV_SEP + str(sourceIp) + CSV_SEP + str(sourcePort) + CSV_SEP + \
           str(destinationIp) + CSV_SEP + str(destinationPort) + CSV_SEP + str(highestLayer)
    if hasPrintaleText:
      line = line + CSV_SEP + printableText
    line = line + CSV_SEP + str(isKafkaMsg) + CSV_SEP + str(isDnsMessage) + "\n"
    if len(line) > 0:
      f.writelines(line)
    print("parsing packet... " + str(seq))
    if isBlockTraffic:
      if isDnsMessage=="True" and len(sourceIp)>0:
        blocked_ip_list[sourceIp] = time.time()
  f.close()
  cap.close()
  print("parse packet file finished!")
  if isBlockTraffic:
    blocking_traffic(blocked_ip_list, blockTime)





def live_dns_detect_in_kafka_traffic(interface=None, capture_filter=None, output_file=None, result_file="ParsedResult.csv", hasPrintaleText=False, packet_count=None, isBlockTraffic=False, blockTime=300, cacheExpireTime=600):
  # Output CSV formats
  capture = pyshark.LiveCapture(interface, capture_filter, output_file, include_raw=True, use_json=True)
  @lazy_cache(maxsize=300, expires=float(cacheExpireTime))
  def CachedBlockIP(blockIP, blockTime):
    blocked_ip_list= {blockIP: time.time()}
    blocking_traffic(blocked_ip_list, blockTime)

  if hasPrintaleText:
    parsedDataHeaders = "Sep,Time,Identification(IP),Source IP,Source Port,Destination IP,Destination Port,Highest_layer,Printable Text,IsKafka Traffic,IsDNS Message"
  else:
    parsedDataHeaders = "Sep,Time,Identification(IP),Source IP,Source Port,Destination IP,Destination Port,Highest_layer,IsKafka Traffic,IsDNS Message"

  CSV_SEP = ","
  seq = 0
  f = ""
  if result_file != None:
    f = codecs.open(result_file, mode="w", encoding="utf-8")
    f.writelines(parsedDataHeaders + "\r\n")

  for packet in capture.sniff_continuously(packet_count):
    seq = seq + 1
    ptime = packet.frame_info.time.replace(",", " ")
    identification = seq
    try:
      sourceIp = packet.ip.src
      identification= packet.ip.id.replace(",", " ")
    except Exception:
      sourceIp = ""
    try:
      sourcePort = packet.tcp.srcport
    except Exception:
      sourcePort = ""
    try:
      destinationIp = packet.ip.dst
    except Exception:
      destinationIp = ""
    try:
      destinationPort = packet.tcp.dstport
    except Exception:
      destinationPort = ""
    try:
      highestLayer = packet.highest_layer.replace(",", " ")
    except Exception:
      highestLayer = ""

    isData = "DATA" in packet
    isSMPP = "SMPP" in packet
    isKafkaMsg = isData or isSMPP
    hex_message = ""
    printableText = ""
    line = ""
    isDnsMessage = "False"
    if isData or isSMPP:
      if isData:
        try:
          hex_message = packet.highest_layer.replace(packet.data_raw.value)
        except Exception:
          hex_message = ""
      if isSMPP:
        try:
          hex_message = packet.smpp_raw.value.replace(",", " ").replace("\r\n", " ").replace('\r', ' ').replace("\n", " ")
        except Exception:
          hex_message = ""
      try:
        printableText = bytes.fromhex(str(hex_message)).decode("utf-8", "ignore")
        printableText = "".join(filter(lambda x: x in string.printable, printableText)).replace(",", " ").replace(
          "\r\n", " ").replace('\r', ' ').replace("\n", " ")
      except Exception:
        printableText = "@SECRYTEXTLABLE@" + str(len(hex_message))
    if len(printableText) > 0:
      lowerText = printableText.lower()
      if "@SECRYTEXTLABLE@" in printableText:
        feature = [int(printableText.split("@SECRYTEXTLABLE@")[1])]
        clf = OneClassSVM(gamma='auto').fit(feature)
        outPut = int(clf.predict(feature)[0])
        if outPut > 0:
          isDnsMessage = True
        else:
          isDnsMessage = False
      else:
        isDnsMessage = "opcode" in lowerText and "question" in lowerText and "answer" in lowerText and "authority" in lowerText and "additional" in lowerText
      # as hex_message is too long we do not store it now.
      # line = str(seq) + CSV_SEP + ptime + CSV_SEP + identification + CSV_SEP + sourceIp + CSV_SEP + sourcePort + CSV_SEP + \
      #        destinationIp + CSV_SEP + destinationPort + CSV_SEP + highestLayer + CSV_SEP + hex_message + CSV_SEP + \
      #        printableText + CSV_SEP + str(isKafkaMsg) + CSV_SEP + str(isDnsMessage) + "\r\n"
    if isBlockTraffic == True and str(isDnsMessage) == "True" and sourceIp != "None" and sourceIp is not None and len(sourceIp) > 0:
      CachedBlockIP(str(sourceIp), blockTime)
    if result_file != None:
      line = str(seq) + CSV_SEP + str(ptime) + CSV_SEP + str(identification) + CSV_SEP + str(sourceIp) + CSV_SEP + str(sourcePort) + CSV_SEP + \
             str(destinationIp) + CSV_SEP + str(destinationPort) + CSV_SEP + str(highestLayer)
      if hasPrintaleText:
        line = line + CSV_SEP + printableText
      line = line + CSV_SEP + str(isKafkaMsg) + CSV_SEP + str(isDnsMessage) + "\n"
      if len(line) > 0:
        f.writelines(line)
    print("parsing packet... " + str(seq) + " IsDNSMessage: " + str(isDnsMessage))
    if packet_count != None and seq == packet_count:
      capture.close()
  if result_file != None:
    f.close()








