import threading
import iptc
import time

# thread responsible for block specific ip
class blockIPThread(threading.Thread):
  def  __init__(self, bip, startTime, blockTime):
    threading.Thread.__init__(self)
    self.bip = bip
    self.startTime = startTime
    self.blockTime = blockTime
  def run(self):
    print ("start blocking ip" + self.bip)
    block_ip_by_time(self.bip, self.startTime, self.blockTime)

def block_IP(blockIP):
  table = iptc.Table(iptc.Table.FILTER)
  chain = iptc.Chain(table, "INPUT")
  rule = iptc.Rule()
  rule.src = str(blockIP)
  target = iptc.Target(rule, "DROP")
  rule.target = target
  chain.insert_rule(rule)
  print("block ip " + blockIP)

def reset_block_rule(sourceIP):
  table = iptc.Table(iptc.Table.FILTER)
  chain = iptc.Chain(table, "INPUT")
  for rule in chain.rules:
    if  sourceIP in rule.src and rule.target.name == "DROP":
      chain.delete_rule(rule)
      print("remove blocked ip " + sourceIP)

def block_ip_by_time(bip, startTime, blockTime):
  currentTime = time.time()
  alreadyBlocked = False
  while float(currentTime)-float(startTime) < blockTime:
    #block ip, update block time
    if alreadyBlocked == False:
      block_IP(bip)
      alreadyBlocked = True
    currentTime = time.time()
  else:
    #block expired, we reset the block rule
    print(str(bip) + "block time" + str(float(currentTime)-float(startTime)))
    reset_block_rule(bip)

def blocking_traffic(blocked_ip_list, blockTime=300):
  if len(blocked_ip_list) > 0:
    print("Block IP ing, the ip list is " + str(blocked_ip_list.keys()))
    threads = []
    for bip in blocked_ip_list:
      threads.append(blockIPThread(bip, blocked_ip_list[bip], blockTime))
    for t in threads:
      t.start()
  print("finish Blocking ip, the ip list is" + str(blocked_ip_list.keys()))