from trafficutils import label_dns_in_kafka_traffic
label_dns_in_kafka_traffic("./dns_data.cap")