from customfirewall import blocking_traffic
from customfirewall import reset_block_rule
import time
blocked_ip_list = {"192.168.81.1":str(time.time())}
blocking_traffic(blocked_ip_list, 60)
# delete the block rule about a specific IP
reset_block_rule("192.168.81.1")