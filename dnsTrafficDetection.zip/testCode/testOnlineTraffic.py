from trafficutils import  live_dns_detect_in_kafka_traffic

live_dns_detect_in_kafka_traffic(interface="ens33", isBlockTraffic=True, blockTime=160)